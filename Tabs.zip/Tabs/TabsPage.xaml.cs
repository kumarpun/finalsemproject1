﻿using Xamarin.Forms;

namespace Tabs
{
    public partial class TabsPage : TabbedPage
    {
        public TabsPage()
        {
            InitializeComponent();
        }
    }
}
