﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Tabs
{
    public partial class AzureTable : ContentPage
    {
        public AzureTable()
        {
            InitializeComponent();
        }
    }
}
